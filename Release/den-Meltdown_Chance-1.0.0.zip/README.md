# Meltdown Chance
Allows users of loaforc's [FacilityMeltdown](https://thunderstore.io/c/lethal-company/p/loaforc/FacilityMeltdown/) to set a percentage change of a meltdown happening
- set value between 0 and 100 in MeltdownChance.xml
- defaults to 100% if file not found or invalid value is given

idk if this actually works 💀