> ## ⚠ Warning ⚠
> This mod changes the *intended behaviour* of the mod [FacilityMeltdown](https://thunderstore.io/c/lethal-company/p/loaforc/FacilityMeltdown/).  As such, it is neither endorsed, nor supported by the original mod's creator.
> If you wish to have the FacilityMeltdown's vanilla experience, without the chance aspect added, only install [FacilityMeltdown](https://thunderstore.io/c/lethal-company/p/loaforc/FacilityMeltdown/) and disregard this mod.


# Meltdown Chance

Mod that allows users of [FacilityMeltdown](https://thunderstore.io/c/lethal-company/p/loaforc/FacilityMeltdown/) to set a percentage change of a meltdown happening

- set value between 0 and 100 in the mod's config



*Please bear with me, as this is my first game mod ever.*