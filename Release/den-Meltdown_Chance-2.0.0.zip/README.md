# Meltdown Chance

Who doesn't love *options*?
Mod that allows users of loaforc's [FacilityMeltdown](https://thunderstore.io/c/lethal-company/p/loaforc/FacilityMeltdown/) to set a percentage change of a meltdown happening

- set value between 0 and 100 in the mod's config



*Please bear with me, as this is my first game mod ever.*