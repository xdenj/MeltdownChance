## 2.0.0

- Now with 100% more functionality! (aka, it actually does *something* now)!
- using bepinex's built-in config functionality

## 1.0.0
- initial reslease